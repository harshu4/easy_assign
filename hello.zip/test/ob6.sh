echo "target/debug/get_output harsh gandhi 180410107028 CE-1 Batch-B"
read a     
echo $a
read b     
echo $b
echo "Enter Choice :"   
echo "1. Addition"   
echo "2. Subtraction"   
echo "3. Multiplication"   
echo "4. Division"   
read ch     
echo $ch
case $ch in   
1)res=`echo $a + $b | bc`     
;;     
2)res=`echo $a - $b | bc`     
;;     
3)res=`echo $a \* $b | bc`     
;;     
4)res=`echo "scale=2; $a / $b" | bc`     
;;     
esac   
echo "Result : $res" 